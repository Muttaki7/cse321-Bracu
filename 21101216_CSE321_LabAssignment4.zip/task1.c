
#include <pthread.h>   
#include <stdio.h>
#include <string.h>
#define MAX 10
#define BUFLEN 6
#define NUMTHREAD 2

void * consumer(int *id);
void * producer(int *id);

char buffer[BUFLEN];
char source[BUFLEN];
int pCount = 0;
int cCount = 0;
int buflen;

pthread_mutex_t count_mutex = PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t nonEmpty  = PTHREAD_COND_INITIALIZER;
pthread_cond_t full  = PTHREAD_COND_INITIALIZER;
int thread_id[NUMTHREAD]  = {01};
int i = 0; 
int j = 0;

int main()
{
    int i;
    pthread_t thread[NUMTHREAD];

    strcpy(source,"abcdef");
    buflen = strlen(source);

    pthread_create(&thread[0], NULL, (void *)producer, &thread_id[0]);
    pthread_create(&thread[1], NULL, (void *)consumer, &thread_id[1]);

    pthread_join(thread[0], NULL);
    pthread_join(thread[1], NULL);

    return 0;
}

void * producer(int *id)
{
    for (int k = 0; k < MAX; k++) {
        pthread_mutex_lock(&count_mutex);
        while (pCount == BUFLEN) {
            pthread_cond_wait(&full, &count_mutex);
        }
        buffer[pCount] = source[i];
        printf("%d produced  %c  by Thread  %d\n", pCount, buffer[pCount], *id);
        i = (i + 1) % buflen;
        pCount++;
        pthread_cond_signal(&nonEmpty);
        pthread_mutex_unlock(&count_mutex);
    }
}

void * consumer(int *id)
{
    for (int k = 0; k < MAX; k++) {
        pthread_mutex_lock(&count_mutex);
        while (pCount == 0) {
            pthread_cond_wait(&nonEmpty, &count_mutex);
        }
        printf("%d consumed  %c  by Thread  %d\n", cCount, buffer[cCount], *id);
        cCount = (cCount + 1) % BUFLEN;
        pCount--;
        pthread_cond_signal(&full);
        pthread_mutex_unlock(&count_mutex);
    }
}
